package caf.war.crearMarcoLogicoTasks.taskclient;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

@ManagedBean(name = "AprobarMarcodelProyectoV2RuleContext")
@SessionScoped
@DTManagedBean(displayName = "Aprobar Marco del Proyecto V2 Rule Context", beanType = BeanType.DEFAULT)
public class AprobarMarcodelProyectoV2RuleContext  extends  com.webmethods.caf.faces.data.task.impl.BaseTaskRuleContext {
}
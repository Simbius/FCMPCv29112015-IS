package caf.war.generaProyectoTasks.taskclient;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

@ManagedBean(name = "CompletaDatosProyectoRuleContext")
public class CompletaDatosProyectoRuleContext  extends  com.webmethods.caf.faces.data.task.impl.BaseTaskRuleContext {
}
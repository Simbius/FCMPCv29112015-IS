package caf.war.generaProyectoTasks.taskclient;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

@ManagedBean(name = "ActualizarContenidosRuleContext")
@SessionScoped
@DTManagedBean(displayName = "Actualizar Contenidos Rule Context", beanType = BeanType.DEFAULT)
public class ActualizarContenidosRuleContext  extends  com.webmethods.caf.faces.data.task.impl.BaseTaskRuleContext {
}
package caf.war.generaProyectoTasks.taskclient;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import com.webmethods.caf.faces.annotations.DTManagedBean;
import com.webmethods.caf.faces.annotations.BeanType;

@ManagedBean(name = "ActualizarMarcoLogicoRuleContext")
@SessionScoped
@DTManagedBean(displayName = "Actualizar Marco Logico Rule Context", beanType = BeanType.DEFAULT)
public class ActualizarMarcoLogicoRuleContext  extends  com.webmethods.caf.faces.data.task.impl.BaseTaskRuleContext {
}
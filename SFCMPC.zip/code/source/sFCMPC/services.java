package sFCMPC;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2015-09-20 19:19:56 PDT
// -----( ON-HOST: localhost.localdomain

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void convertidorNumerico (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertidorNumerico)>> ---
		// @sigtype java 3.5
		// [i] object:0:required numero
		// [o] field:0:required cadena
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	numero = IDataUtil.get( pipelineCursor, "numero" );
		pipelineCursor.destroy();
		String cadena=  numero.toString();
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "cadena", cadena );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}
}

